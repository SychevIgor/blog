﻿namespace Sychev.AzureApiManagement.DataModel
{
	public class Revision
	{
		public User User { get; set; }
	}
}