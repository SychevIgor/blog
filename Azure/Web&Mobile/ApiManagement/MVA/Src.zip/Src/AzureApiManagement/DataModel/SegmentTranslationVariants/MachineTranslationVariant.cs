﻿namespace Sychev.AzureApiManagement.DataModel
{
	public class MachineTranslationVariant
	{
		 
	}
}