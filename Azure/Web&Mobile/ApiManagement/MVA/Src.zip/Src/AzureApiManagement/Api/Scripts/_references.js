﻿/// <autosync enabled="true" />
/// <reference path="bootstrap.js" />
/// <reference path="jquery-1.10.2.js" />
/// <reference path="jquery-ui-1.10.2.js" />
/// <reference path="knockout-3.2.0.js" />
/// <reference path="modernizr-2.8.3.js" />
/// <reference path="webapitestclient.js" />
